package com.example.pianoplayer

import android.content.Context

object Keys {
    private val black = setOf(1, 3, 6, 8, 10)
    fun isBlack(midi: Int) = (midi % 12) in black

    // 白鍵序號 A0=0 .. C8=51；黑鍵存的是「它右邊那個白鍵」的序號
    val whiteIdx = IntArray(128)
    // 白鍵序號 -> MIDI 音高
    val whiteMidi = IntArray(52)

    init {
        var c = 0
        for (m in 21..108) {
            whiteIdx[m] = c
            if (!isBlack(m)) {
                whiteMidi[c] = m
                c++
            }
        }
    }

    private val names = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    fun name(m: Int): String = names[m % 12] + (m / 12 - 1)
}

class Calibration(ctx: Context) {
    private val sp = ctx.getSharedPreferences("calibration", Context.MODE_PRIVATE)

    var x1 = sp.getFloat("x1", 0f)              // 畫面可見最左白鍵的 x
    var x2 = sp.getFloat("x2", 0f)              // 畫面可見最右白鍵的 x
    var yW = sp.getFloat("yW", 0f)              // 白鍵按壓 y
    var yB = sp.getFloat("yB", 0f)              // 黑鍵按壓 y
    var lowWhite = sp.getInt("lowWhite", 0)     // 最左可見白鍵序號（0 = A0）
    var highWhite = sp.getInt("highWhite", 51)  // 最右可見白鍵序號（51 = C8）
    var blackShift = sp.getFloat("blackShift", 0f)    // 黑鍵整體左右偏移 (px)
    var blackSpread = sp.getFloat("blackSpread", 0f)  // 黑鍵仿真偏移（白鍵寬度的比例）
    var fold = sp.getBoolean("fold", true)      // 超出範圍的音：true=折疊八度，false=跳過

    val ready: Boolean get() = x2 > x1 && yW > 0f && yB > 0f && highWhite > lowWhite

    fun save() {
        sp.edit()
            .putFloat("x1", x1).putFloat("x2", x2)
            .putFloat("yW", yW).putFloat("yB", yB)
            .putInt("lowWhite", lowWhite).putInt("highWhite", highWhite)
            .putFloat("blackShift", blackShift).putFloat("blackSpread", blackSpread)
            .putBoolean("fold", fold)
            .apply()
    }

    fun setPoints(x1: Float, x2: Float, yW: Float, yB: Float) {
        this.x1 = x1
        this.x2 = x2
        this.yW = yW
        this.yB = yB
    }

    /** 改變可見範圍時，琴鍵的實際位置保持不動（只重新換算兩端座標） */
    fun setRange(low: Int, high: Int) {
        val l = low.coerceIn(0, 51)
        val h = high.coerceIn(0, 51)
        if (h - l < 7) return
        if (ready) {
            val nx1 = whiteX(l.toFloat())
            val nx2 = whiteX(h.toFloat())
            x1 = nx1
            x2 = nx2
        }
        lowWhite = l
        highWhite = h
    }

    private fun whiteX(w: Float): Float =
        x1 + (x2 - x1) * (w - lowWhite) / (highWhite - lowWhite).toFloat()

    private fun pos(k: Int): Float =
        if (Keys.isBlack(k)) Keys.whiteIdx[k] - 0.5f else Keys.whiteIdx[k].toFloat()

    private fun inRange(k: Int): Boolean {
        val p = pos(k)
        return p >= lowWhite && p <= highWhite
    }

    /** 回傳實際會按的音；超出範圍時折疊八度或回傳 null（跳過） */
    fun resolve(key: Int): Int? {
        var k = key
        if (k < 21 || k > 108) return null
        if (inRange(k)) return k
        if (!fold) return null
        val below = pos(k) < lowWhite
        while (k in 21..108 && !inRange(k)) {
            k += if (below) 12 else -12
        }
        return if (k in 21..108 && inRange(k)) k else null
    }

    fun pointFor(key: Int): Pair<Float, Float>? {
        val k = resolve(key) ?: return null
        val ww = (x2 - x1) / (highWhite - lowWhite)
        return if (Keys.isBlack(k)) {
            var x = whiteX(pos(k)) + blackShift
            // 仿真：C#、F# 略偏左，D#、A# 略偏右，G# 居中
            x += when (k % 12) {
                1, 6 -> -blackSpread * ww
                3, 10 -> blackSpread * ww
                else -> 0f
            }
            Pair(x.coerceAtLeast(0f), yB.coerceAtLeast(0f))
        } else {
            Pair(whiteX(Keys.whiteIdx[k].toFloat()).coerceAtLeast(0f), yW.coerceAtLeast(0f))
        }
    }
}
