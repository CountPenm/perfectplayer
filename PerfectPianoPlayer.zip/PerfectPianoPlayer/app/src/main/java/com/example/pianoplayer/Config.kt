package com.example.pianoplayer

import android.content.Context
import android.content.SharedPreferences

/** 時間相關參數，可在「微調」面板即時修改並自動保存 */
object Config {
    @Volatile var windowMs = 150.0        // 同一批手勢合併多少毫秒內的音符
    @Volatile var leadMs = 20L            // 提前多少毫秒送出手勢（補償注入延遲）
    @Volatile var minHoldMs = 30.0        // 每個按鍵最短按住時間
    @Volatile var maxHoldMs = 90.0        // 未開延音時最長按住時間
    @Volatile var sustainCapMs = 260.0    // 開延音時最長按住時間
    @Volatile var lateDropMs = 350.0      // 落後超過此毫秒數的音直接丟棄，避免越拖越慢
    @Volatile var startDelaySec = 3       // 按播放後的倒數秒數
    @Volatile var sustainOn = true

    private var sp: SharedPreferences? = null

    fun load(ctx: Context) {
        val s = ctx.getSharedPreferences("config", Context.MODE_PRIVATE)
        sp = s
        windowMs = s.getFloat("windowMs", windowMs.toFloat()).toDouble()
        leadMs = s.getLong("leadMs", leadMs)
        minHoldMs = s.getFloat("minHoldMs", minHoldMs.toFloat()).toDouble()
        maxHoldMs = s.getFloat("maxHoldMs", maxHoldMs.toFloat()).toDouble()
        sustainCapMs = s.getFloat("sustainCapMs", sustainCapMs.toFloat()).toDouble()
        lateDropMs = s.getFloat("lateDropMs", lateDropMs.toFloat()).toDouble()
        startDelaySec = s.getInt("startDelaySec", startDelaySec)
        sustainOn = s.getBoolean("sustainOn", sustainOn)
    }

    fun save() {
        val s = sp ?: return
        s.edit()
            .putFloat("windowMs", windowMs.toFloat())
            .putLong("leadMs", leadMs)
            .putFloat("minHoldMs", minHoldMs.toFloat())
            .putFloat("maxHoldMs", maxHoldMs.toFloat())
            .putFloat("sustainCapMs", sustainCapMs.toFloat())
            .putFloat("lateDropMs", lateDropMs.toFloat())
            .putInt("startDelaySec", startDelaySec)
            .putBoolean("sustainOn", sustainOn)
            .apply()
    }
}
