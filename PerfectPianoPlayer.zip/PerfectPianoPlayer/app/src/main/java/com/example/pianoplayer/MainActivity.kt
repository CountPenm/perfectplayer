package com.example.pianoplayer

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SongHolder.restore(this)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        val title = TextView(this)
        title.text = "鋼琴 MIDI 自動演奏"
        title.textSize = 22f

        status = TextView(this)
        status.textSize = 15f
        status.setPadding(0, pad, 0, pad)

        val pick = Button(this)
        pick.text = "① 選擇 MIDI 檔"
        pick.setOnClickListener { pickMidi() }

        val acc = Button(this)
        acc.text = "② 開啟無障礙設定"
        acc.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }

        val help = TextView(this)
        help.textSize = 14f
        help.setPadding(0, pad, 0, 0)
        help.text = "使用步驟：\n" +
            "1. 選擇 MIDI 檔（會自動記住，下次不用重選）。\n" +
            "2. 在無障礙設定裡找到本應用並開啟，螢幕上會出現懸浮控制條。\n" +
            "3. 切到遊戲，橫屏。若畫面不是完整 88 鍵，先點控制條「更多 > 微調」設定可見的最左、最右琴鍵。\n" +
            "4. 點「校準」，依提示點三個位置；再用「測試」「掃描」檢查，不準就在「微調」裡一格一格挪。\n" +
            "5. 按 ▶，倒數結束後開始演奏。\n\n" +
            "控制條：♪ 可點擊收合、拖曳移動；« » 前後跳 10 秒；− + 調速度；「更多」展開其他功能。\n" +
            "「延音」開啟時，會依 MIDI 裡的踏板訊號拉長按鍵時間來模仿延音。\n" +
            "「選曲」若沒有反應，請手動回到本應用選擇。"

        root.addView(title)
        root.addView(status)
        root.addView(pick)
        root.addView(acc)
        root.addView(help)

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        val s = SongHolder.song
        val songText = if (s == null) {
            "尚未選擇"
        } else {
            val sec = (s.durationMs / 1000).toInt()
            val lo = Keys.name(s.notes.minOf { it.key })
            val hi = Keys.name(s.notes.maxOf { it.key })
            "${SongHolder.name}\n${s.notes.size} 個音符，時長 ${sec / 60}:${"%02d".format(sec % 60)}，音域 $lo–$hi"
        }
        val svcText = if (PianoService.instance != null) "已啟動" else "未啟動"
        status.text = "MIDI：$songText\n無障礙服務：$svcText"
    }

    private fun pickMidi() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        startActivityForResult(i, 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 1 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            val song = MidiParser.parse(bytes)
            val name = queryName(uri)
            SongHolder.song = song
            SongHolder.name = name
            SongHolder.remember(this, bytes, name)
        } catch (e: Exception) {
            Toast.makeText(this, "讀取失敗：${e.message}", Toast.LENGTH_LONG).show()
        }
        refreshStatus()
    }

    private fun queryName(uri: Uri): String {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) return c.getString(idx)
        }
        return "MIDI"
    }
}
