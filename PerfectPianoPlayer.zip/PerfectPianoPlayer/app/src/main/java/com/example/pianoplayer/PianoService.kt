package com.example.pianoplayer

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs

class PianoService : AccessibilityService() {

    companion object {
        @Volatile var instance: PianoService? = null
    }

    private lateinit var wm: WindowManager
    private lateinit var calib: Calibration
    private lateinit var player: Player
    private val ui = Handler(Looper.getMainLooper())

    private var panel: LinearLayout? = null
    private var btnPlay: Button? = null
    private var btnSustain: Button? = null
    private var btnDelay: Button? = null
    private var btnFold: Button? = null
    private var tvInfo: TextView? = null
    private var calibView: View? = null
    private var nudgePanel: LinearLayout? = null

    private val steps = floatArrayOf(1f, 2f, 5f, 10f, 20f)
    private var stepIdx = 1
    private fun stepPx(): Float = steps[stepIdx]

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 300)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Config.load(this)
        SongHolder.restore(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        calib = Calibration(this)
        player = Player(this, calib)
        buildPanel()
        ui.post(ticker)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        ui.removeCallbacks(ticker)
        if (::player.isInitialized) player.stop()
        removeCalib()
        removeNudge()
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        instance = null
        return super.onUnbind(intent)
    }

    // ---------------------------------------------------------------- 小工具

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun hRow(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        return r
    }

    private fun addBtn(parent: LinearLayout, label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.textSize = 13f
        b.setTextColor(Color.WHITE)
        b.isAllCaps = false
        b.minWidth = 0
        b.minimumWidth = 0
        b.minHeight = 0
        b.minimumHeight = 0
        b.setPadding(dp(10), dp(6), dp(10), dp(6))
        val bg = GradientDrawable()
        bg.setColor(0xFF3A3A4A.toInt())
        bg.cornerRadius = dp(8).toFloat()
        b.background = bg
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(dp(3), dp(2), dp(3), dp(2))
        parent.addView(b, lp)
        return b
    }

    private fun panelBackground(): GradientDrawable {
        val bg = GradientDrawable()
        bg.setColor(0xCC202030.toInt())
        bg.cornerRadius = dp(12).toFloat()
        return bg
    }

    private fun overlayParams(): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        return lp
    }

    /** 拖曳 handle 移動 target 視窗；沒有移動就當作點擊 */
    private fun makeDraggable(
        handle: View,
        target: View,
        lp: WindowManager.LayoutParams,
        onTap: (() -> Unit)?
    ) {
        handle.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0
            var sy = 0
            var tx = 0f
            var ty = 0f
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = lp.x
                        sy = lp.y
                        tx = e.rawX
                        ty = e.rawY
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - tx
                        val dy = e.rawY - ty
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                        if (moved) {
                            lp.x = sx + dx.toInt()
                            lp.y = sy + dy.toInt()
                            try { wm.updateViewLayout(target, lp) } catch (_: Exception) {}
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) onTap?.invoke()
                    }
                }
                return true
            }
        })
    }

    private fun persist() {
        calib.save()
        Config.save()
    }

    // ---------------------------------------------------------------- 主控制條

    private fun buildPanel() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.HORIZONTAL
        root.gravity = Gravity.CENTER_VERTICAL
        root.background = panelBackground()
        root.setPadding(dp(6), dp(4), dp(6), dp(4))

        val handle = TextView(this)
        handle.text = "♪"
        handle.textSize = 20f
        handle.setTextColor(Color.WHITE)
        handle.setPadding(dp(8), dp(2), dp(8), dp(2))

        val bodyBox = LinearLayout(this)
        bodyBox.orientation = LinearLayout.VERTICAL

        val r1 = hRow()
        val r2 = hRow()
        r2.visibility = View.GONE

        btnPlay = addBtn(r1, "▶") { onPlayClicked() }
        addBtn(r1, "⏹") { player.stop(); refresh() }
        addBtn(r1, "«") { player.seekBy(-10.0); refresh() }
        addBtn(r1, "»") { player.seekBy(10.0); refresh() }
        val info = TextView(this)
        info.textSize = 12f
        info.setTextColor(Color.WHITE)
        info.setPadding(dp(4), 0, dp(4), 0)
        r1.addView(info)
        tvInfo = info
        addBtn(r1, "−") { changeSpeed(-0.1) }
        addBtn(r1, "+") { changeSpeed(0.1) }
        addBtn(r1, "更多") {
            r2.visibility = if (r2.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }

        btnSustain = addBtn(r2, "延音:開") {
            Config.sustainOn = !Config.sustainOn
            Config.save()
            refresh()
        }
        btnDelay = addBtn(r2, "倒數:3秒") { cycleDelay() }
        btnFold = addBtn(r2, "超界:折疊") {
            calib.fold = !calib.fold
            calib.save()
            refresh()
        }
        addBtn(r2, "測試") {
            if (!calib.ready) toast("請先校準") else player.test()
        }
        addBtn(r2, "掃描") {
            if (!calib.ready) toast("請先校準") else player.sweep()
            refresh()
        }
        addBtn(r2, "選曲") { openPicker() }
        addBtn(r2, "校準") { startCalibration() }
        addBtn(r2, "微調") { toggleNudge() }

        bodyBox.addView(r1)
        bodyBox.addView(r2)
        root.addView(handle)
        root.addView(bodyBox)

        val lp = overlayParams()
        lp.x = dp(16)
        lp.y = dp(8)
        makeDraggable(handle, root, lp) {
            bodyBox.visibility = if (bodyBox.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        panel = root
        wm.addView(root, lp)
        refresh()
    }

    private fun onPlayClicked() {
        if (player.playing) {
            player.pause()
        } else {
            if (SongHolder.song == null) { toast("請先在應用裡選擇 MIDI 檔"); return }
            if (!calib.ready) { toast("請先點「更多 > 校準」"); return }
            player.play()
        }
        refresh()
    }

    private fun changeSpeed(delta: Double) {
        val v = Math.round((player.speed + delta) * 20.0) / 20.0
        player.setSpeedValue(v.coerceIn(0.25, 2.0))
        refresh()
    }

    private fun cycleDelay() {
        val opts = intArrayOf(0, 3, 5, 10)
        val i = opts.indexOf(Config.startDelaySec)
        Config.startDelaySec = opts[(i + 1) % opts.size]
        Config.save()
        refresh()
    }

    private fun openPicker() {
        try {
            val i = Intent(this, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            toast("請手動打開本應用選曲")
        }
    }

    private fun fmt(ms: Double): String {
        val s = (ms / 1000).toInt()
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    private fun refresh() {
        if (!::player.isInitialized) return
        btnPlay?.text = if (player.playing) "⏸" else "▶"
        btnSustain?.text = if (Config.sustainOn) "延音:開" else "延音:關"
        btnDelay?.text = "倒數:${Config.startDelaySec}秒"
        btnFold?.text = if (calib.fold) "超界:折疊" else "超界:跳過"
        val cd = player.countdownSec()
        tvInfo?.text = if (cd > 0) {
            "倒數 $cd"
        } else {
            String.format(
                Locale.US, "%s/%s %.2fx",
                fmt(player.positionMs()), fmt(player.durationMs()), player.speed
            )
        }
    }

    // ---------------------------------------------------------------- 校準

    private fun startCalibration() {
        player.pause()
        removeCalib()
        val lo = Keys.name(Keys.whiteMidi[calib.lowWhite])
        val hi = Keys.name(Keys.whiteMidi[calib.highWhite])
        val prompts = listOf(
            "校準 1/3\n點擊畫面最左邊白鍵（$lo）的按壓位置",
            "校準 2/3\n點擊畫面最右邊白鍵（$hi）的按壓位置",
            "校準 3/3\n點擊任意一個黑鍵的按壓位置"
        )
        val pts = ArrayList<Pair<Float, Float>>()
        val root = FrameLayout(this)
        root.setBackgroundColor(0x55000000)
        val tv = TextView(this)
        tv.text = prompts[0]
        tv.setTextColor(Color.WHITE)
        tv.textSize = 18f
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(24), dp(24), dp(24), dp(24))
        tv.setBackgroundColor(0xAA000000.toInt())
        root.addView(
            tv,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        )
        root.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                pts.add(Pair(e.rawX, e.rawY))
                if (pts.size < 3) {
                    tv.text = prompts[pts.size]
                } else {
                    calib.setPoints(pts[0].first, pts[1].first, pts[0].second, pts[2].second)
                    calib.save()
                    removeCalib()
                    toast("校準完成，可用「測試」「掃描」檢查")
                }
            }
            true
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(root, lp)
        calibView = root
    }

    private fun removeCalib() {
        calibView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        calibView = null
    }

    // ---------------------------------------------------------------- 微調面板

    private fun addRow(
        parent: LinearLayout,
        label: () -> String,
        l: String,
        r: String,
        onL: () -> Unit,
        onR: () -> Unit
    ) {
        val row = hRow()
        val tv = TextView(this)
        tv.textSize = 12f
        tv.setTextColor(Color.WHITE)
        row.addView(tv, LinearLayout.LayoutParams(dp(150), LinearLayout.LayoutParams.WRAP_CONTENT))
        fun upd() { tv.text = label() }
        addBtn(row, l) { onL(); persist(); upd() }
        addBtn(row, r) { onR(); persist(); upd() }
        upd()
        parent.addView(row)
    }

    private fun toggleNudge() {
        if (nudgePanel != null) {
            removeNudge()
            return
        }
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = panelBackground()
        root.setPadding(dp(8), dp(6), dp(8), dp(6))

        val titleRow = hRow()
        val title = TextView(this)
        title.text = "≡ 微調（拖曳此處移動）"
        title.textSize = 13f
        title.setTextColor(Color.WHITE)
        title.setPadding(dp(4), dp(4), dp(12), dp(4))
        titleRow.addView(title)
        addBtn(titleRow, "試音") {
            if (!calib.ready) toast("請先校準") else player.test()
        }
        addBtn(titleRow, "掃描") {
            if (!calib.ready) toast("請先校準") else player.sweep()
        }
        addBtn(titleRow, "完成") { removeNudge() }
        root.addView(titleRow)

        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL

        addRow(list, { "步長 ${stepPx().toInt()}px" }, "−", "+",
            { stepIdx = (stepIdx - 1).coerceAtLeast(0) },
            { stepIdx = (stepIdx + 1).coerceAtMost(steps.size - 1) })

        addRow(list, { "範圍左端 ${Keys.name(Keys.whiteMidi[calib.lowWhite])}" }, "◀", "▶",
            { calib.setRange(calib.lowWhite - 1, calib.highWhite) },
            { calib.setRange(calib.lowWhite + 1, calib.highWhite) })
        addRow(list, { "範圍右端 ${Keys.name(Keys.whiteMidi[calib.highWhite])}" }, "◀", "▶",
            { calib.setRange(calib.lowWhite, calib.highWhite - 1) },
            { calib.setRange(calib.lowWhite, calib.highWhite + 1) })

        addRow(list, { "左端位置 x=${calib.x1.toInt()}" }, "◀", "▶",
            { calib.x1 -= stepPx() }, { calib.x1 += stepPx() })
        addRow(list, { "右端位置 x=${calib.x2.toInt()}" }, "◀", "▶",
            { calib.x2 -= stepPx() }, { calib.x2 += stepPx() })
        addRow(list, { "整體左右" }, "◀", "▶",
            { calib.x1 -= stepPx(); calib.x2 -= stepPx() },
            { calib.x1 += stepPx(); calib.x2 += stepPx() })
        addRow(list, { "白鍵高度 y=${calib.yW.toInt()}" }, "▲", "▼",
            { calib.yW -= stepPx() }, { calib.yW += stepPx() })
        addRow(list, { "黑鍵高度 y=${calib.yB.toInt()}" }, "▲", "▼",
            { calib.yB -= stepPx() }, { calib.yB += stepPx() })
        addRow(list, { "黑鍵左右 ${calib.blackShift.toInt()}px" }, "◀", "▶",
            { calib.blackShift -= stepPx() }, { calib.blackShift += stepPx() })
        addRow(list, { String.format(Locale.US, "黑鍵仿真偏移 %.2f", calib.blackSpread) }, "−", "+",
            { calib.blackSpread = (calib.blackSpread - 0.02f).coerceIn(-0.3f, 0.3f) },
            { calib.blackSpread = (calib.blackSpread + 0.02f).coerceIn(-0.3f, 0.3f) })

        addRow(list, { "提前量 ${Config.leadMs}ms" }, "−", "+",
            { Config.leadMs = (Config.leadMs - 5L).coerceAtLeast(0L) },
            { Config.leadMs = (Config.leadMs + 5L).coerceAtMost(200L) })
        addRow(list, { "按住時長 ${Config.maxHoldMs.toInt()}ms" }, "−", "+",
            { Config.maxHoldMs = (Config.maxHoldMs - 10.0).coerceAtLeast(30.0) },
            { Config.maxHoldMs = (Config.maxHoldMs + 10.0).coerceAtMost(400.0) })
        addRow(list, { "延音上限 ${Config.sustainCapMs.toInt()}ms" }, "−", "+",
            { Config.sustainCapMs = (Config.sustainCapMs - 50.0).coerceAtLeast(100.0) },
            { Config.sustainCapMs = (Config.sustainCapMs + 50.0).coerceAtMost(2000.0) })
        addRow(list, { "合併窗口 ${Config.windowMs.toInt()}ms" }, "−", "+",
            { Config.windowMs = (Config.windowMs - 25.0).coerceAtLeast(50.0) },
            { Config.windowMs = (Config.windowMs + 25.0).coerceAtMost(400.0) })

        val sv = ScrollView(this)
        sv.addView(list)
        root.addView(sv, LinearLayout.LayoutParams(dp(330), dp(190)))

        val lp = overlayParams()
        lp.x = dp(16)
        lp.y = dp(90)
        makeDraggable(title, root, lp, null)
        nudgePanel = root
        wm.addView(root, lp)
    }

    private fun removeNudge() {
        nudgePanel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        nudgePanel = null
    }
}
