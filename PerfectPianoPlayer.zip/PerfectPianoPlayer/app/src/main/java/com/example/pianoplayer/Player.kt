package com.example.pianoplayer

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import kotlin.math.ceil
import kotlin.math.max

class Player(private val svc: AccessibilityService, private val calib: Calibration) {
    private val handler = Handler(Looper.getMainLooper())
    private val maxStrokes = 10

    @Volatile var speed = 1.0
    @Volatile var playing = false
        private set

    private var tempSong: Song? = null   // 掃描試音用的臨時曲目
    private var idx = 0
    private var anchorWall = 0L
    private var anchorSong = 0.0
    private var startAtWall = 0L
    private var epoch = 0

    private val dispatchRunnable = Runnable { dispatchChunk() }
    private val nextRunnable = Runnable { scheduleNext() }

    private fun cur(): Song? = tempSong ?: SongHolder.song

    private fun songTime(): Double =
        anchorSong + (SystemClock.uptimeMillis() - anchorWall) * speed

    fun positionMs(): Double {
        val d = cur()?.durationMs ?: 0.0
        return (if (playing) songTime() else anchorSong).coerceIn(0.0, d)
    }

    fun durationMs(): Double = cur()?.durationMs ?: 0.0

    fun countdownSec(): Int {
        if (!playing) return 0
        val rem = startAtWall - SystemClock.uptimeMillis()
        return if (rem > 0) ceil(rem / 1000.0).toInt() else 0
    }

    fun play(delaySec: Int = Config.startDelaySec): Boolean {
        val s = cur() ?: return false
        if (idx >= s.notes.size) {
            idx = 0
            anchorSong = 0.0
        }
        startAtWall = SystemClock.uptimeMillis() + delaySec * 1000L
        anchorWall = startAtWall
        playing = true
        epoch++
        scheduleNext()
        return true
    }

    fun pause() {
        if (!playing) return
        anchorSong = songTime().coerceAtLeast(0.0)
        playing = false
        epoch++
        handler.removeCallbacks(dispatchRunnable)
        handler.removeCallbacks(nextRunnable)
    }

    fun stop() {
        playing = false
        epoch++
        handler.removeCallbacks(dispatchRunnable)
        handler.removeCallbacks(nextRunnable)
        idx = 0
        anchorSong = 0.0
        tempSong = null
    }

    fun setSpeedValue(v: Double) {
        if (playing) {
            anchorSong = songTime()
            anchorWall = SystemClock.uptimeMillis()
        }
        speed = v
    }

    /** 前進/後退 sec 秒 */
    fun seekBy(sec: Double) {
        val s = cur() ?: return
        val t = (positionMs() + sec * 1000.0).coerceIn(0.0, s.durationMs)
        anchorSong = t
        anchorWall = SystemClock.uptimeMillis()
        startAtWall = anchorWall
        idx = firstIndexAtOrAfter(s.notes, t)
        if (playing) {
            epoch++
            handler.removeCallbacks(dispatchRunnable)
            handler.removeCallbacks(nextRunnable)
            scheduleNext()
        }
    }

    private fun firstIndexAtOrAfter(notes: List<Note>, t: Double): Int {
        var lo = 0
        var hi = notes.size
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (notes[mid].startMs < t) lo = mid + 1 else hi = mid
        }
        return lo
    }

    private fun finish() {
        playing = false
        idx = 0
        anchorSong = 0.0
        tempSong = null
    }

    private fun scheduleNext() {
        if (!playing) return
        handler.removeCallbacks(dispatchRunnable)
        val notes = cur()?.notes ?: return
        if (idx >= notes.size) {
            finish()
            return
        }
        val wait = ((notes[idx].startMs - songTime()) / speed).toLong() - Config.leadMs
        if (wait > 4) handler.postDelayed(dispatchRunnable, wait) else dispatchChunk()
    }

    private fun dispatchChunk() {
        if (!playing) return
        val notes = cur()?.notes ?: return
        val now = songTime()

        // 落後太多的音直接丟棄，讓演奏追回進度
        while (idx < notes.size && (now - notes[idx].startMs) / speed > Config.lateDropMs) idx++
        if (idx >= notes.size) {
            finish()
            return
        }

        val first = notes[idx]
        val builder = GestureDescription.Builder()
        val used = HashSet<Int>()
        val sustain = Config.sustainOn
        var count = 0
        var j = idx
        while (j < notes.size && count < maxStrokes) {
            val n = notes[j]
            if (n.startMs > first.startMs + Config.windowMs) break
            val rk = calib.resolve(n.key)
            if (rk == null) { j++; continue }
            if (!used.add(rk)) break
            val pt = calib.pointFor(rk)
            if (pt == null) { j++; continue }
            val startWall = max(0.0, (n.startMs - now) / speed).toLong()
            val endSrc = if (sustain) n.sustainEndMs else n.endMs
            val cap = if (sustain) Config.sustainCapMs else Config.maxHoldMs
            val hold = ((endSrc - n.startMs) / speed).coerceIn(Config.minHoldMs, cap).toLong()
            val path = Path().apply { moveTo(pt.first, pt.second) }
            builder.addStroke(GestureDescription.StrokeDescription(path, startWall, hold))
            count++
            j++
        }
        idx = j

        if (count == 0) {
            handler.post(nextRunnable)
            return
        }

        val myEpoch = epoch
        val cb = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                if (epoch == myEpoch) scheduleNext()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                if (epoch == myEpoch) scheduleNext()
            }
        }
        val ok = try {
            svc.dispatchGesture(builder.build(), cb, handler)
        } catch (e: Exception) {
            false
        }
        if (!ok) handler.post(nextRunnable)
    }

    /** 試音：按 C4..A4 共 10 個鍵（含黑鍵） */
    fun test() {
        val b = GestureDescription.Builder()
        var i = 0
        for (k in 60..69) {
            val pt = calib.pointFor(k) ?: continue
            val path = Path().apply { moveTo(pt.first, pt.second) }
            b.addStroke(GestureDescription.StrokeDescription(path, i * 180L, 80L))
            i++
        }
        if (i > 0) svc.dispatchGesture(b.build(), null, null)
    }

    /** 掃描：由低到高逐鍵（含黑鍵）彈一遍範圍內所有琴鍵，用來檢查兩端有沒有對準 */
    fun sweep() {
        stop()
        val list = ArrayList<Note>()
        var t = 0.0
        for (k in 21..108) {
            if (calib.resolve(k) == k) {
                list.add(Note(k, t, t + 80.0, t + 80.0, 90))
                t += 110.0
            }
        }
        if (list.isEmpty()) return
        tempSong = Song(list, t)
        play(0)
    }
}
